<?xml version="1.0" encoding="UTF-8"?>
<tileset version="1.5" tiledversion="1.6.0" name="grass_tiles" tilewidth="64" tileheight="64" tilecount="5" columns="5">
 <image source="../../graphics/decoration/grass/grass.png" width="320" height="64"/>
</tileset>
